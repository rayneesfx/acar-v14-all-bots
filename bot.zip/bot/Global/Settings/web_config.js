let web_info = {
  port: 4433,
  api: "127.0.0.1",
};

let info = {
  username: "acar",
  password: "1234",
};

module.exports = { web_info, info };
